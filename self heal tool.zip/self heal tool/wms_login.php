<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">

    <title>
      
        Nike Self Healing 
      
    </title>

    <link href="http://fonts.googleapis.com/css?family=Roboto:300,400,500,700,400italic" rel="stylesheet">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
   <link rel="icon" href="nike1.png" type="image/x-icon" />
    
      <link href="css/toolkit-inverse.css" rel="stylesheet">
    <link href="css/application.css" rel="stylesheet">
    <link href="css/login.css" rel="stylesheet">
    <script>
        $(document).ready(function() {
            $(".dropdown-toggle").dropdown();
         $(".dropdown-menu li a").click(function(){
          var selText = $(this).text();
          $(this).parents('.btn-group').find('.dropdown-toggle').html(selText);
        });
        });
        

            
    </script>

    <style>
      /* note: this is a hack for ios iframe for bootstrap themes shopify page */
      /* this chunk of css is not part of the toolkit :) */
      body {
        width: 1px;
        min-width: 100%;
        *width: 100%;
      }
        
        .button_stl {
              background-color: white;
              width: 75%;
              color: black;
              padding: 8px 45px;
              text-align: center;
              text-decoration: none;
              display: inline-block;
              cursor: pointer;
              border-radius: 0px;
              font-weight: bold;
        }
        
        .btn {
             margin-top:8px;
        }
        
        .button_stl:hover {
            box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);
        }
        
        .row{
            padding: 30px 0px;
        }
        
        option{
            background-color: azure;
            padding: 27px 20px;
        }
        input::-webkit-input-placeholder { /* Chrome/Opera/Safari */
          color: black;
        }
        input::-moz-placeholder { /* Firefox 19+ */
          color: black;
        }
        input:-ms-input-placeholder { /* IE 10+ */
          color: black;
        }
        input:-moz-placeholder { /* Firefox 18- */
          color: black;
        }
        input::placeholder {
  color: red;
}
    </style>
  </head>


<body>
<div class="with-iconav">
  <div class="container">
    <div class="dashhead">
      <div class="dashhead-titles">
        <h6 class="dashhead-subtitle"></h6>
        <h3 class="dashhead-title" style="align:center">NIKE Self-Heal Tool</h3>
      </div>
     </div>
    <hr class="m-t-0 m-b-lg">
<!--?php
if (!$POST.isset ("usrclass")){ ?>

<form   id = "loginForm"  action = 'Dashboard Page.php' method = 'POST'>

<!--?php }?>



       <!--Login Form start-->
    <form   id = "loginForm"  action = 'Dashboard Page.php' method = 'POST'>
    
    <div class="form-signin">
      <!--<img style="align:center;margin-left:100px;" class="mb-4" src="nike1.png" alt="" width="72" height="72">-->
      <h1 class="h3 mb-3 font-weight-normal"> Login </h1>
      <label for="usrtype" class="sr-only1">User Type</label> <br>
      <select class="form-control" name = "usrtyp" id = "usrtyp">
      <option value = "User"> User </option>
      <option value = "Admin"> Admin </option>
      </select><br>
      <!--script>
                  
                    $("#usrtyp").change(function(){
                      
                      var rgnlbl = document.getElementById('regionlbl');
                      var dbrgn = document.getElementById('dbregion');
                      console.log("User type changed" + this.options[this.selectedIndex].value);
                      rgnlbl.style.visibility = "hidden";
                      dbrgn.style.visibility = "hidden";
                      if (usrtyp.options[usrtyp.selectedIndex].value ==="User")
                      {
                          rgnlbl.style.visibility = "visible";
                          dbrgn.style.visibility = "visible";

                      }
                      
                    })
      </script-->
      <label for="dbregion" class="sr-only1" id = "regionlbl">Region</label> <br>
      <select class="form-control" name = "Region" id = "dbregion">
      <?php
      $conn = mysqli_connect('localhost', 'root', '','test');
      $a = "Select Data_Target from region";
      $result = mysqli_query($conn,$a);
      //$row = mysqli_fetch_array($result);
      while($row = mysqli_fetch_array($result)) {
        //echo "<button id = 'btn' style = 'width:200px; height:30px;color:blue'>" . $row['category'] . "</button>";
        echo "<option  value = " . $row['Data_Target'] . ">" .$row['Data_Target'] . "</option>" ;
      } 
      
      mysqli_close($conn);
      ?>
      </select><br>
      <label for="inputUserId" class="sr-only1">User Id</label>
      <input name = "userid" type="text" id="inputUserId" class="form-control" placeholder="User Id" style="background-color:white;color:black" required="" autofocus="">
      <label for="inputPassword" class="sr-only1">Password</label>
      <input type="password" name ="pwd" id="inputPassword" class="form-control" placeholder="Password" style="background-color:white;color:black" required="">
      <div class="checkbox mb-3">
        <label>
          <input type="checkbox" value="remember-me"> Remember me
        </label>
      </div>
      <button id = 'sbmLogin' class="btn btn-lg btn-primary btn-block"  onclick="signin()" >Sign in</button>
      <!--input type = "submit"  name = 'sbmBtn' id = 'sbmLogin' class="btn btn-lg btn-primary btn-block" value = "Sign in"-->
      <label id = "invVldLogin" class="sr-only1" style = "color:red;"></label>
      <input name = "server" id="servernm" style="visibility:hidden">
      
      <p class="mt-5 mb-3 text-muted">© 2018-2019</p> 
      
    </div> <!-- Login Form Ends -->
    </form>


  </div>
</div>


    <script src="js/jquery.min.js"></script>
    <script src="js/chart.js"></script>
    <script src="js/tablesorter.min.js"></script>
    <script src="js/toolkit.js"></script>
    <script src="js/application.js"></script>
    <script>
      // execute/clear BS loaders for docs
      $(function(){while(window.BS&&window.BS.loader&&window.BS.loader.length){(window.BS.loader.pop())()}})
    </script>
    <script src="heal.js">
    </script>
    
    <script>
    
function ValidateEmail(email)
{
        var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        if(email.value.match(mailformat))
        {
        //document.form1.text1.focus();
            console.log('validate success');
        return true;
        }
        else
        {
        alert("You have entered an invalid email address!");
        //document.form1.text1.focus();
        console.log('validate success');
        return false;
        }
}

//$("form").submit(signin)
function signin(){
        var  userId = document.getElementById( "inputUserId" ).value ? document.getElementById( "inputUserId" ).value : 'undefined';
        var pass = document.getElementById( "inputPassword" ).value ? document.getElementById( "inputPassword" ).value : 'undefined';
        var servnm = document.getElementById("servernm");
        var invvld = document.getElementById( "invVldLogin");
        var btnId = document.getElementById( "sbmLogin");
        var formId = document.getElementById( "loginForm");
        var regionid = document.getElementById("dbregion");
        var region = regionid.options[regionid.selectedIndex].value;
        var usertype = usrtyp.options[usrtyp.selectedIndex].value;
        var errflg = ' '
        
        invvld.innerHTML = " ";
        
        console.log('Gopal '+userId);
        console.log('Krishna '+pass);
        console.log('User Type'+usertype);
            
        if((!userId || userId === 'undefined') &&(!pass || pass === 'undefined')){
           document.getElementById('inputUserId').style.borderColor="red";
           document.getElementById('inputPassword').style.borderColor="red"; 
        }
        else if (!userId || userId === 'undefined'){
            document.getElementById('inputUserId').style.borderColor="red";
        }else if(!pass || pass === 'undefined'){
            document.getElementById('inputPassword').style.borderColor="red";     
        }
        else{
            //var validate = ValidateEmail(email);
            
                        $.ajax({
                        type: "POST",
                        url: 'selfservice.php',
                        dataType: 'json',
                        data: {functionname: 'dblogin', arguments: [userId,pass,region,usertype]},

                        success: function (obj) {
                            
                            console.log(obj.test);
                            if ("result" in obj)
                            {
                                console.log(obj.result);
                                errflg  = 'N';
                                console.log(errflg);
                                servnm.value = ' ';
                                if(usertype === 'User')
                                  servnm.value = obj.servernm;
                                formId.submit()
                                
                            }
                            else
                            {                   
                               errflg = 'Y'            
                               btnId.disabled = false;
                               btnId.innerHTML = "Sign in"
                               invvld.innerHTML = "Invalid User Id or Password";
                               console.log(obj.error);                 
                            }
                            
                                },
                        error: function(err)
                                {  
                                   btnId.disabled = false;
                                   btnId.innerHTML = "Sign in"
                                   invvld.innerHTML = "Invalid User Id or Password";
                                   errflg = 'Y'
                                   console.log("Gopal found the errorlogging")
                                   console.log(err);
                                    
                                   
                                }
                                // async:false
                        
                            });

             
            btnId.innerHTML = '<span class="spinner-grow spinner-grow-sm" role="status" aria-hidden="false"></span>  Signing in...';
            btnId.disabled = true;
            
            
            /*if (errflg == 'Y' )
            {
                invvld.innerHTML = "Invalid User Id or Password";
                return(false);
            }
            return(false)*/
            
            
        }

        
}
    
    </script>
  </body>
</html>

