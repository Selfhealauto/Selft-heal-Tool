<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">

    <title>
      
        Nike Self Healing 
      
    </title>

    <link href="http://fonts.googleapis.com/css?family=Roboto:300,400,500,700,400italic" rel="stylesheet">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
   <link rel="icon" href="nike1.png" type="image/x-icon" />
    
      <link href="css/toolkit-inverse.css" rel="stylesheet">
    <link href="css/application.css" rel="stylesheet">
    <script>
        $(document).ready(function() {
            $(".dropdown-toggle").dropdown();
         $(".dropdown-menu li a").click(function(){
          var selText = $(this).text();
          $(this).parents('.btn-group').find('.dropdown-toggle').html(selText);
        });
        });
        

            
    </script>

    <style>
      /* note: this is a hack for ios iframe for bootstrap themes shopify page */
      /* this chunk of css is not part of the toolkit :) */
      body {
        width: 1px;
        min-width: 100%;
        *width: 100%;
      }
        
        .button_stl {
              background-color: white;
              width: 75%;
              color: black;
              padding: 8px 45px;
              text-align: center;
              text-decoration: none;
              display: inline-block;
              cursor: pointer;
              border-radius: 0px;
              font-weight: bold;
        }
        
        .btn {
             margin-top:8px;
        }
        
        .button_stl:hover {
            box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);
        }
        
        .row{
            padding: 30px 0px;
        }
        
        option{
            background-color: azure;
            padding: 27px 20px;
        }
    </style>
  </head>


<body>

<div class="with-iconav">
  <div class="container">
    <div class="dashhead">
      <div class="dashhead-titles">
        <h6 class="dashhead-subtitle"></h6>
        <h3 class="dashhead-title" style="align:center">NIKE Self-Heal Tool - Input Screen </h3>
      </div>
     </div>
    <hr class="m-t-0 m-b-lg">


<?php

if(isset($_POST['submit']))
{ 

        //echo "issue selected is {$_POST['issue']}";
//echo "successfully posted"; 

        $usrnm = $_POST['userid'];
        $dbpwd = $_POST['pwd'];
        $servnm = $_POST['server'];
        
        $conn = mysqli_connect('localhost', 'root', '','test');
        if (!$conn) {
          
          die("Connection failed: " . mysqli_connect_error());
        } 
        else{
          $Region = 'NALC';
           //echo "connected";
           $issue = $_POST['issue'];
           echo "<form  onSubmit = 'return Validate()' action='class 2 fetch SQL.php' method = 'POST'>";
           echo "<input  name = 'issue' value = $issue READONLY style = 'visibility:hidden'> <br><br>";
           //echo '<select style = "width:200px; height:30px;color:blue" name = "issue"> <option value = " "> Select Issue </option> ';
           $a = "Select Input_Parm, Place_Holder from input where Data_Target = '$Region' and issue_name = '$issue'";

           $result = mysqli_query($conn,$a);
           $count  = 1;
           while($row = mysqli_fetch_array($result))
           {  
            $ipname = $row['Place_Holder'];
            echo "<br><label class='sr-only1'>"  .$row['Input_Parm'] . ": </label> <br>";
            echo "<input class='form-control' style='width:200px;' name = " . $ipname . "> <br>";
           }

           echo "<br><input type = 'submit' name = 'ipsubmit' class='form-control' style = 'width : 200px'  value = 'submit'>";
           echo "<input name = 'userid' style = 'visibility:hidden' value = '$usrnm'>";
           echo "<input name = 'pwd' style = 'visibility:hidden' value = '$dbpwd'>";
           echo "<input name = 'server' style = 'visibility:hidden' value = '$servnm'>";
           echo "</form>";
          }
        }
        else
        {
          
          if(isset($_POST['ipsubmit']))
          {

            $usrnm = $_POST['userid'];
            $dbpwd = $_POST['pwd'];
            $servnm = $_POST['server'];
            $ora_conn = oci_connect($usrnm, $dbpwd, $servnm);
            echo "testing connection ";
            
            //$server = 'wc1014pe.cz8mdzpqprux.us-east-1.rds.amazonaws.com';
            if (!$ora_conn) {
            
                echo "Connection failed";
                $e = oci_error();
                echo $e['message'];
                //trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
            }
            else
               echo "<br> connected to oracle server \"" . $servnm . "\" successfully";
          
            $Region = 'NALC';
            $issue = $_POST['issue'];
            $totenbr = $_POST['&01'];
            $PlcHldrArr = [];
            echo "<br> issue selected is $issue";
            // echo "<br> Tote# nbr is $totenbr";

            $conn = mysqli_connect('localhost', 'root', '','test');
            
            $a = "Select  Place_Holder from input where Data_Target = '$Region' and Issue_Name = '$issue'";
            $result = mysqli_query($conn, $a);
            $i = 0;
            while ($row = mysqli_fetch_array($result))
            {
               $PlcHldrArr[$i++] = $row['Place_Holder'];
            }
            
            $a = "Select Query, Rcd_Cnt from query where Data_Target = '$Region' and Issue_Name = '$issue' and qry_type = 'VLD'";
            
            $result = mysqli_query($conn, $a);

            $vldflg = 'Y';

            while ($row = mysqli_fetch_array($result))
            {
                  $vldqry = $row['Query'];
                  $Rcd_Cnt = $row['Rcd_Cnt'];
                  $i = 0;
                  $nbrofips = count($PlcHldrArr);
                  while($i < $nbrofips)
                  {
                        $vldqry = str_replace($PlcHldrArr[$i], $_POST[$PlcHldrArr[$i]], $vldqry);
                        $i++;
                  }
                  echo "<br> $vldqry";
                  echo "<br> Record count flag is  $Rcd_Cnt <br>";
                  $stid= oci_parse($ora_conn, $vldqry);

                  $r = oci_execute($stid); 
                  
                  if ($wmsrow = oci_fetch_array($stid, OCI_ASSOC+OCI_RETURN_NULLS))
                      if ($Rcd_Cnt == 'N') 
                      {
                         echo "<br> problem does not belong $issue issue";
                         $vldflg = 'N';
                         break;
                      }

                      else
                          echo "<br> problem belongs to $issue issue";

                  else
                      if ($Rcd_Cnt == 'Y') 
                      {
                         echo "<br> problem does not belong $issue issue";
                         $vldflg = 'N';
                         break;
                      }
                      else
                         echo "<br> problem belongs to $issue issue"; 
            }
            if ($vldflg == 'Y')
            {
               $a = "Select Query, Rcd_Cnt from query where Data_Target = '$Region' and Issue_Name = '$issue' and qry_type = 'EXE'";
               
               $result = mysqli_query($conn, $a);

               $vldflg = 'Y';

               while ($row = mysqli_fetch_array($result))
               {
                     $execqry = $row['Query'];
                     $Rcd_Cnt = $row['Rcd_Cnt'];
                     $i = 0;
                     $nbrofips = count($PlcHldrArr);
                     while($i < $nbrofips)
                     {
                           $execqry = str_replace($PlcHldrArr[$i], $_POST[$PlcHldrArr[$i]], $execqry);
                           $i++;
                     } ?>

                     <script> alert("successfully executed") </script>
                     <?php
                     echo "<br> Execution Query is:  $execqry";
                     
               }   
            }
          }  
        }
?>
<script>
  function Validate()
  {
    
    var ipIds = document.getElementsByClassName('form-control')
    var Errflg = ' N'
    console.log('Started validations');

    for(NbrofIps = 0; NbrofIps < ipIds.length; NbrofIps++)
    {
         console.log('navigating through IP ' + ipIds[NbrofIps].name)
      
         if(ipIds[NbrofIps].name.charAt(0) == "&" && ipIds[NbrofIps].value.trim() === "")
         {
           Errflg = 'Y'
         }
    }

    console.log('error flag is ' + Errflg)
    if(Errflg == 'Y')
      return(false)

  }
</script>

</body>
</html>

