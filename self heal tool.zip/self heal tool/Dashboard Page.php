<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">

    <title>
      
        Nike Self Healing 
      
    </title>

    <link href="http://fonts.googleapis.com/css?family=Roboto:300,400,500,700,400italic" rel="stylesheet">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
   <link rel="icon" href="nike1.png" type="image/x-icon" />
    
      <link href="css/toolkit-inverse.css" rel="stylesheet">
    <link href="css/application.css" rel="stylesheet">
    <script>
        $(document).ready(function() {
            $(".dropdown-toggle").dropdown();
         $(".dropdown-menu li a").click(function(){
          var selText = $(this).text();
          $(this).parents('.btn-group').find('.dropdown-toggle').html(selText);
        });
        });
        

            
    </script>

    <style>
      /* note: this is a hack for ios iframe for bootstrap themes shopify page */
      /* this chunk of css is not part of the toolkit :) */
      body {
        width: 1px;
        min-width: 100%;
        *width: 100%;
      }
        
        .button_stl {
              background-color: white;
              width: 75%;
              color: black;
              padding: 8px 45px;
              text-align: center;
              text-decoration: none;
              display: inline-block;
              cursor: pointer;
              border-radius: 0px;
              font-weight: bold;
        }
        
        .btn {
             margin-top:8px;
        }
        
        .button_stl:hover {
            box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);
        }
        
        .row{
            padding: 30px 0px;
        }
        
        option{
            background-color: azure;
            padding: 27px 20px;
        }
    </style>
  </head>


<body>

<?php 
if(isset($_POST["userid"]))
{
  $usrnm = $_POST['userid'];
  $dbpwd = $_POST['pwd'];
  $servnm = $_POST['server'];
  $Region = $_POST['Region'];
  ?>

<div class="with-iconav">
  <div class="container">
    <div class="dashhead">
      <div class="dashhead-titles">
        <h6 class="dashhead-subtitle"></h6>
        <h3 class="dashhead-title">NIKE Self-Heal Tool</h3>
      </div>
            
      <div class="dashhead-toolbar">       
        <div class="btn-group dashhead-toolbar-item">
          <!--<div class="btn-group">
              <button type="button" class="btn btn-primary-outline dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> NALC
              </button>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#">China</a></li>
                <li><a class="dropdown-item" href="#">Europe</a></li>
                <li><a class="dropdown-item" href="#">Japan</a></li>
                <li><a class="dropdown-item" href="#">Mexico</a></li>
                <li><a class="dropdown-item" href="#">South Korea</a></li>
                <li><a class="dropdown-item" href="#">NALC</a></li>
              </ul>
              
            <!--<select type="button" class="btn btn-primary-outline dropdown-toggle" aria-haspopup="true" aria-expanded="false" style="height:35px">
              <option value="volvo"><a class="dropdown-item" href="#">China</a></option>
              <option value="saab"><a class="dropdown-item" href="#">Europe</a></option>
              <option value="vw"><a class="dropdown-item" href="#">Japan</a></option>
              <option value="vw"><a class="dropdown-item" href="#">Mexico</a></option>
              <option value="vw"><a class="dropdown-item" href="#">South Korea</a></option>
              <option value="audi" selected><a class="dropdown-item" href="#">NALC</a></option>
            </select>>
          </div>
         
          <button type="button" class="btn btn-primary-outline">Log Ticket</button>
            <button type="button" class="btn btn-primary-outline"> <a href="http://localhost\self%20heal%20tool\index_admin_login.php">Admin</a></button>
          <button type="button" class="btn btn-primary-outline"><a href="http://localhost\self%20heal%20tool\Visio-Nike_Message_Interface_flow.pdf">Help</a></button>--->      
        </div>
      </div>
      
    </div>

<?php
if(isset($_POST['usrtyp']))
{
	$usrtype = $_POST['usrtyp'];
}
if ($usrtype!="Admin")
{
?>
    <ul class="nav nav-bordered m-t m-b-0" role="tablist">
      <li class="active" role="presentation">
        <a href="#dashboardtab" role="tab" data-toggle="tab" aria-controls="dashboardtab" style="color:white">Dashboard</a>
      </li>
      <li role="presentation">
        <a href="#inbound" role="tab" data-toggle="tab" aria-controls="inbound" style="color:white">Inbound</a>
      </li>
      <li role="presentation">
        <a href="#outbound" role="tab" data-toggle="tab" aria-controls="outbound" style="color:white">Outbound</a>
      </li> 
     <li role="presentation">
        <a href="#inventory" role="tab" data-toggle="tab" aria-controls="inventory" style="color:white">Inventory</a>
      </li>
	 </ul>
<?php
}
else
{
?>
	<ul class="nav nav-bordered m-t m-b-0" role="tablist">
		<li class="active" role="presentation">
			<a href="#dashboardtab" role="tab" data-toggle="tab" aria-controls="dashboardtab" style="color:white">Dashboard</a>
		 </li>
		<li role="presentation">
			<a href="#miscellaneous" role="tab" data-toggle="tab" aria-controls="miscellaneous" style="color:white">Miscellaneous</a>
		</li>
    </ul>
<?php
}
?>
<?php
	$conn = mysqli_connect('localhost', 'root', '','test');
	$b="SELECT SUM(count) as sum
		FROM (SELECT  count(*) AS count 
				FROM menu where category='Inbound' AND data_target='$Region'
				GROUP BY sub_category) As Tables";
    $result = mysqli_query($conn,$b);
	
	while($row1=mysqli_fetch_array($result))
	{
	$sum=$row1['sum'];
	}
	$a="SELECT  sub_category,count(*) AS count 
				FROM menu where category='Inbound' AND data_target='$Region'
				GROUP BY sub_category;";
	$res=mysqli_query($conn,$a);
	while($row2=mysqli_fetch_array($res))
	{
		if ($row2['sub_category']=="ASN")
		{
			$asnPercent = number_format(($row2['count']/$sum)*100,1);
		}
		else if ($row2['sub_category']=="Trailer")
		{
			$trailerPercent = number_format(($row2['count']/$sum)*100,1);
		}
		else
		{
			$putawayPercent = number_format(($row2['count']/$sum)*100,1);
		}
	}
	
?>
    <hr class="m-t-0 m-b-lg">

    <div class="tab-content">
      <div role="tabpanel" class="tab-pane active" id="dashboardtab">
        <div class="row text-center m-t-md">
          <div class="col-sm-3 m-b-md">
            <div class="w-lg m-x-auto">
              <canvas
                class="ex-graph"
                width="200" height="200"
                data-chart="doughnut"
                data-value="[{ value: <?php echo $asnPercent; ?>, color: '#42a5f5', label: 'ASN' }, { value: <?php echo $trailerPercent; ?>, color: '#1bc98e', label: 'Trailer' },{ value: <?php echo $putawayPercent; ?>, color: '#f22e55', label: 'putaway sorting' }]"
                data-segment-stroke-color="#222">
              </canvas>
            </div>
            <strong class="text-muted" style="color:white">Inbound</strong>
            <!--<h3>New vs Returning</h3>-->
          </div>
		   <?php
	$conn = mysqli_connect('localhost', 'root', '','test');
	
	$a="SELECT sub_category,count(*) AS count 
			FROM menu where category='outbound' AND data_target='$Region' 
			GROUP BY sub_category";
	$b="SELECT SUM(count) as sum 
			FROM (SELECT count(*) AS count 
				FROM menu where category='outbound' AND data_target='$Region' 
				GROUP BY sub_category) As Tables";
    $result = mysqli_query($conn,$b);
	while($row1=mysqli_fetch_array($result))
	{
	$sum=$row1['sum'];
	}
	$res=mysqli_query($conn,$a);
	while($row2=mysqli_fetch_array($res))
	{
		if ($row2['sub_category']=="MANIFEST")
		{
			$manifestPercent = number_format(($row2['count']/$sum)*100,1);
		}
		else if ($row2['sub_category']=="Shipping")
		{
			$shippingPercent = number_format(($row2['count']/$sum)*100,1);
		}
		else if ($row2['sub_category']=="Order")
		{
			$orderPercent = number_format(($row2['count']/$sum)*100,1);
		}
		else
		{
			$taskPercent = number_format(($row2['count']/$sum)*100,1);
		}
	}
	
?>
          <div class="col-sm-3 m-b-md">
            <div class="w-lg m-x-auto">
              <canvas
                class="ex-graph"
                width="200" height="200"
                data-chart="doughnut"
                data-value="[{ value: <?php echo $manifestPercent; ?>, color: '#42a5f5', label: 'Manifest' }, { value: <?php echo $shippingPercent; ?> , color: '#1bc98e', label: 'Shipping' },{ value: <?php echo $orderPercent; ?>, color: '#f22e55', label: 'Order' },{ value: <?php echo $taskPercent; ?>, color: '#f1e82e', label: 'Task' }]"
                data-segment-stroke-color="#222">
              </canvas>
            </div>
            <strong class="text-muted" style="color:white">Outbound</strong>
            <!--<h3>New vs Recurring</h3>-->
          </div>
		  <?php
	$conn = mysqli_connect('localhost', 'root', '','test');
	
	$a="SELECT sub_category,count(*) AS count 
			FROM menu where category='Inventory' AND data_target='$Region' 
			GROUP BY sub_category";
	$b="SELECT SUM(count) as sum 
			FROM (SELECT count(*) AS count 
				FROM menu where category='inventory' AND data_target='$Region' 
				GROUP BY sub_category) As Tables";
    $result = mysqli_query($conn,$b);
	while($row1=mysqli_fetch_array($result))
	{
	$sum=$row1['sum'];
	}
	$res=mysqli_query($conn,$a);
	while($row2=mysqli_fetch_array($res))
	{
		if ($row2['sub_category']=="Cycle Count")
		{
			$cyclecountPercent = number_format(($row2['count']/$sum)*100,1);
		}
		else if ($row2['sub_category']=="First Sku")
		{
			$firstskuPercent = number_format(($row2['count']/$sum)*100,1);
		}
		else if ($row2['sub_category']=="Damage")
		{
			$damagePercent = number_format(($row2['count']/$sum)*100,1);
		}
		else
		{
			$returnPercent = number_format(($row2['count']/$sum)*100,1);
		}
	}
	
?>
          <div class="col-sm-3 m-b-md">
            <div class="w-lg m-x-auto">
              <canvas
                class="ex-graph"
                width="200" height="200"
                data-chart="doughnut"
                data-value="[{ value: <?php echo $cyclecountPercent; ?>, color: '#42a5f5', label: 'Cycle count' }, { value: <?php echo $firstskuPercent; ?>, color: '#1bc98e', label: 'First Sku' },{ value: <?php echo $damagePercent; ?>, color: '#f22e55', label: 'Damage' },{ value: <?php echo $returnPercent; ?>, color: '#f1e82e', label: 'Return' }]"
                data-segment-stroke-color="#222">
              </canvas>
            </div>
            <strong class="text-muted" style="color:white">Inventory</strong>
            <!--<h3>Direct vs Referrals</h3>-->
          </div>
          <!--- <div class="col-sm-3 m-b-md">
            <div class="w-lg m-x-auto">
              <canvas
                class="ex-graph"
                width="200" height="200"
                data-chart="doughnut"
                data-value="[{ value: 61, color: '#42a5f5', label: 'New Issue' }, { value: 39, color: '#1bc98e', label: 'Known Issue' }]"
                data-segment-stroke-color="#222">
              </canvas>
            </div>
            <strong class="text-muted" style="color:white">Miscellaneous</strong>
            <!--<h3>Direct vs Referrals</h3>
          </div> --->
        </div>
   
        
<!-- Dashboard overview start here -->   
<div class="hr-divider m-t m-b">
      <h3 class="hr-divider-content hr-divider-heading">Quick stats</h3>
</div>
  
    
    <div class="row">
      <div class="col-md-3 m-b-md">
        <div class="list-group">
          <h4 class="list-group-header">
            Inbound
          </h4>
            <a class="list-group-item" style="color:white">
              <span class="list-group-progress" style="width: <?php echo $asnPercent; ?>%;background-color:#42a5f5;opacity: 0.5;"></span>
			<span class="pull-right text-muted" style="color:white"><?php echo $asnPercent; ?>%</span>
              ASN
            </a>
          
            <a class="list-group-item" style="color:white">
              <span class="list-group-progress" style="width: <?php echo $trailerPercent; ?>%;background-color:#1bc98e;opacity: 0.5;"></span>
              <span class="pull-right text-muted" style="color:white"><?php echo $trailerPercent; ?>%</span>
              Trailer
            </a>
          
            <a class="list-group-item" style="color:white">
              <span class="list-group-progress" style="width: <?php echo $putawayPercent; ?>%;background-color:#f22e55;opacity: 0.5;"></span>
              <span class="pull-right text-muted" style="color:white"><?php echo $putawayPercent; ?>%</span>
              Putaway Sorting
            </a>          
        </div>
      </div>
	 
	
      <div class="col-md-3 m-b-md">
        <div class="list-group">
          <h4 class="list-group-header">
            Outbound
          </h4>
          
            <a class="list-group-item" style="color:white">
              <span class="list-group-progress" style="width: <?php echo $manifestPercent; ?>%;background-color:#42a5f5;opacity: 0.5;"></span>
              <span class="pull-right text-muted" style="color:white"><?php echo $manifestPercent; ?>%</span>
              Manifest
            </a>
          
            <a class="list-group-item" style="color:white">
              <span class="list-group-progress" style="width: <?php echo $shippingPercent; ?>%;background-color:#1bc98e;opacity: 0.5;"></span>
              <span class="pull-right text-muted" style="color:white"><?php echo $shippingPercent; ?>%</span>
              Shipping
            </a>
          
            <a class="list-group-item" style="color:white">
              <span class="list-group-progress" style="width: <?php echo $orderPercent; ?>%;background-color:#f22e55;opacity: 0.5;"></span>
              <span class="pull-right text-muted" style="color:white"><?php echo $orderPercent; ?>%</span>
              Order
            </a>
          
            <a class="list-group-item" style="color:white">
              <span class="list-group-progress" style="width: <?php echo $taskPercent; ?>%;background-color:#f1e82e;opacity: 0.5;"></span>
              <span class="pull-right text-muted" style="color:white"><?php echo $taskPercent; ?>%</span>
              Task
            </a>          
        </div>
      </div>
	  <?php
	 mysqli_close($conn);
	 ?>
      <div class="col-md-3 m-b-md">
        <div class="list-group">
          <h4 class="list-group-header">
            Inventory
          </h4>
          
            <a class="list-group-item" style="color:white">
              <span class="list-group-progress" style="width: <?php echo $cyclecountPercent;?>%;background-color:#42a5f5;opacity: 0.5;"></span>
              <span class="pull-right text-muted" style="color:white"><?php echo $cyclecountPercent;?>%</span>
              Cycle count
            </a>
          
            <a class="list-group-item" style="color:white">
              <span class="list-group-progress" style="width: <?php echo $firstskuPercent; ?>%;background-color:#1bc98e;opacity: 0.5;"></span>
              <span class="pull-right text-muted" style="color:white"><?php echo $firstskuPercent; ?>%</span>
              First Sku
            </a>
          
            <a class="list-group-item" style="color:white">
              <span class="list-group-progress" style="width: <?php echo $damagePercent; ?>%;background-color:#f22e55;opacity: 0.5;"></span>
              <span class="pull-right text-muted" style="color:white"><?php echo $damagePercent; ?>%</span>
              Damage
            </a>
          
            <a class="list-group-item" style="color:white">
              <span class="list-group-progress" style="width: <?php echo $returnPercent; ?>%;background-color:#f1e82e;opacity: 0.5;"></span>
              <span class="pull-right text-muted" style="color:white"><?php echo $returnPercent; ?>%</span>
              Return
            </a>
        </div>
      </div>
      
      <!--- <div class="col-md-3 m-b-md">
        <div class="list-group">
          <h4 class="list-group-header">
            Miscellaneous
          </h4>
          
            <a class="list-group-item" style="color:white">
              <span class="list-group-progress" style="width: 61.0%;background-color:#42a5f5;opacity: 0.5;"></span>
              <span class="pull-right text-muted" style="color:white">61.0%</span>
              New Issue
            </a>
          
            <a class="list-group-item" style="color:white">
              <span class="list-group-progress" style="width: 39.0%;background-color:#1bc98e;opacity: 0.5;"></span>
              <span class="pull-right text-muted" style="color:white">39.0%</span>
              Known Issue
            </a>
        </div>
      </div> --->
    </div><!-- Dashboard overview end here -->
        
      </div>
   <!-- TAB PHP start here -->   
 
        <!--OUTBOUND START-->
<?php
      echo "<div role='tabpanel' class='tab-pane' id='outbound'>";
        //echo "<div class='m-b-md'>";

                $conn = mysqli_connect('localhost', 'root', '','test');
                if (!$conn) {
                    die("Connection failed: " . mysqli_connect_error());
                }         
        
                            //OUTBOUND START
                           $a = "Select data_target,issue_name,sub_category,category from menu where category='outbound' and data_target = '$Region' order by sub_category";
                    $result = mysqli_query($conn,$a);
                    echo "<div class='row' id='outbound'>";
					$prv_sub_cat=" ";
					
				$count=0;
                 while($row = mysqli_fetch_array($result)) {
				  if ($prv_sub_cat <> $row['sub_category'])
				  {
					if ($count > 0)
						echo "</div>";
					
					$count = 0;

					$textval = $row['sub_category'];
					$prv_sub_cat = $textval;
					 //echo "<div class='hr-divider s-t s-b' style='margin-top:10px;padding:0px;top:10%'>";
						
					 echo "<h3 class='hr-divider-content hr-divider-heading''>".$textval."</h3>";
					 //echo "</div>";
						 
					 echo "<div class='row' id='outbound'>";
				  }
				  elseif ($count == 3) 
				  {
					 echo "</div>";
					 $count=0;
					echo "<div class='row'>";
				  }
                    
                                $modelid = trim($row['data_target']) . trim($row['issue_name']);
                                echo "<div class='col-sm-4'>";
                                    echo "<button class='btn btn-primary-outline button_stl' data-toggle='modal' data-target=#". $modelid .">". $row['issue_name'] ."</button>";
                                echo "</div>";
                                $count++;
                                
                    }
                        echo "</div>";
                    
                    echo "</div>";
        //echo "</div";
      echo "</div>";//OUTBOUND END
            
        //INBOUND start
      echo "<div role='tabpanel' class='tab-pane' id='inbound'>";
                    $a = "Select data_target,issue_name,sub_category,category from menu where category='inbound' and data_target = '$Region' order by sub_category";
                    $result = mysqli_query($conn,$a);
                    echo "<div class='row' id='inbound'>";
					$prv_sub_cat=" ";
					
				$count=0;
                 while($row = mysqli_fetch_array($result)) {
				  if ($prv_sub_cat <> $row['sub_category'])
				  {
					if ($count > 0)
						echo "</div>";
					
					$count = 0;

					$textval = $row['sub_category'];
					$prv_sub_cat = $textval;
					 //echo "<div class='hr-divider s-t s-b' style='margin-top:10px;padding:0px;top:10%'>";
						
					 echo "<h3 class='hr-divider-content hr-divider-heading''>".$textval."</h3>";
					 //echo "</div>";
						 
					 echo "<div class='row' id='inbound'>";
				  }
				  elseif ($count == 3) 
				  {
					 echo "</div>";
					 $count=0;
					echo "<div class='row'>";
				  }
                    
                                $modelid = trim($row['data_target']) . trim($row['issue_name']);
                                echo "<div class='col-sm-4'>";
                                    echo "<button class='btn btn-primary-outline button_stl' data-toggle='modal' data-target=#". $modelid .">". $row['issue_name'] ."</button>";
                                echo "</div>";
                                $count++;
                                
                    }
                        echo "</div>";
                    
                    echo "</div>";
      echo "</div>";//INBOUND END
        
        
      //INVENTORY start
      echo "<div role='tabpanel' class='tab-pane' id='inventory'>";
                    $a = "Select data_target,issue_name,sub_category,category from menu where category='inventory' and data_target = '$Region' order by sub_category";
                    $result = mysqli_query($conn,$a);
                    echo "<div class='row' id='inventory'>";
					$prv_sub_cat=" ";
					
				$count=0;
                 while($row = mysqli_fetch_array($result)) {
				  if ($prv_sub_cat <> $row['sub_category'])
				  {
					if ($count > 0)
						echo "</div>";
					
					$count = 0;

					$textval = $row['sub_category'];
					$prv_sub_cat = $textval;
					 //echo "<div class='hr-divider s-t s-b' style='margin-top:10px;padding:0px;top:10%'>";
						
					 echo "<h3 class='hr-divider-content hr-divider-heading''>".$textval."</h3>";
					 //echo "</div>";
						 
					 echo "<div class='row' id='inbound'>";
				  }
				  elseif ($count == 3) 
				  {
					 echo "</div>";
					 $count=0;
					echo "<div class='row'>";
				  }
                    
                                $modelid = trim($row['data_target']) . trim($row['issue_name']);
                                echo "<div class='col-sm-4'>";
                                    echo "<button class='btn btn-primary-outline button_stl' data-toggle='modal' data-target=#". $modelid .">". $row['issue_name'] ."</button>";
                                echo "</div>";
                                $count++;
                                
                    }
                        echo "</div>";
                    
                    echo "</div>";
      echo "</div>";//INVENTORY END
        

		
		
      //MISCELLANEOUS start
      echo "<div role='tabpanel' class='tab-pane' id='miscellaneous'>";
                    $a = "Select data_target,issue_name,category from menu where category='miscellaneous'";
                    $result = mysqli_query($conn,$a);
                    echo "<div class='row' id='misce'>";

                    for ($i = 1;$i<=mysqli_num_rows($result);$i+=3){            
                        $count = 0;            
                        if ($i % 3 === 1){
                           echo "<h3 class='hr-divider-content hr-divider-heading''> New Issues </h3>";
                        echo "<div class='row'>";
                        }

                    while($row = mysqli_fetch_array($result)) {
                                $modelid = trim($row['data_target']) . trim($row['issue_name']);
                                echo "<div class='col-sm-4'>";
                                    echo "<button class='btn btn-primary-outline button_stl' data-toggle='modal' data-target=#". $modelid .">". $row['issue_name'] ."</button>";
                                echo "</div>"; 
                        $count++;
                        if($count ===3){break;}
                    }
                        echo "</div>";
                    }
                    echo "</div>";
      echo "</div>";//MISCELLANEOUS END
        
        mysqli_close($conn);
?>
     



<!--MODAL Page setup -->

   <?php
        
        $conn = mysqli_connect('localhost', 'root', '','test');
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }        
        //$a = "Select data_target,issue_name,category,input_label,function_name,sql_query from menu";
    
        $a = "Select issue_name, Data_Target from input where data_target = '$Region' group by issue_name, Data_Target";
        
        //MODAL Page code start
$result = mysqli_query($conn,$a);
$prev_issue = "";
$prev_Datatgt = "";
while($row = mysqli_fetch_array($result)) {   
  $modelid = trim($row['Data_Target']) . trim($row['issue_name']);     
    echo "<div class='modal fade' id=". $modelid ." tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true'>";
      echo "<div class='modal-dialog' role='document'>";
        echo "<div class='modal-content'>";
          echo "<div class='modal-header'>";
            echo "<h5 class='modal-title' id='exampleModalLabel' style='color:black;font-weight:bold;'>". $row['issue_name'] ."</h5>";
              
            echo "<button type='button' class='close' onclick=modalclose() data-dismiss='modal' aria-label='Close'>";
              echo "<span aria-hidden='true'>&times;</span>";
            echo "</button>";
          echo "</div>";
          echo "<div class='modal-body'>";

            echo "<form class='form-horizontal'>";

/*                 echo "<div class='form-group'>";
                    echo "<label for='inputEmail3' class='col-sm-3 control-label'>Incident : </label>";
                    echo "<div class='col-sm-10'>";
                      echo "<input type='email' class='form-control' id='OIncident' placeholder='' value=''>";
                    echo "</div>";
                  echo "</div>";*/
    
    $b = "select input_parm, Place_Holder from input where data_target ='" .$row['Data_Target']. "' and issue_name='".$row['issue_name']."' order by input_seq";
    $result1 = mysqli_query($conn,$b);
    $parm =array();
    while($fld = mysqli_fetch_array($result1)) {  
                  echo "<div class='form-group inputfldcass'>";
                    echo "<label style='text-align:center' for='inputEmail3' class='col-sm-4 control-label'>". $fld['input_parm'] .": </label>";
                    echo "<div class='col-sm-8'>";
                      echo "<input type='text' class='form-control input_fld".$row['issue_name']."' name=" . $fld['Place_Holder'] ." placeholder='' value=''>";
                    echo "</div>";
                  echo "</div>";
        array_push($parm,$fld['input_parm']);
        //$parm = $parm."'".$fld['input_field']."',";
    }
    $parm = join(" ",$parm);

            echo "</form>";

          echo "</div>";
          echo "<div class='modal-footer'>";
            echo "<button type='button' class='btn btn-secondary' onclick=modalclose() data-dismiss='modal'>Close</button>";
            echo "<button type='button' class='btn btn-primary' id = 'execbtn".$row['issue_name']."' onclick=\"execute('" . $row['Data_Target']. "', '" .$row['issue_name']. "','$usrnm', '$dbpwd', '$servnm')\">Execute </button>";
            // echo "<button type='button' class='btn btn-primary' onclick=execute('".$row['issue_name']."')>Execute </button>";
          echo "</div>";
        echo "</div>";
      echo "</div>";
    echo "</div>";
        
//Modal page code end
}
        
        mysqli_close($conn);
?>
   
<!-- Modal page setup end-->
     
     
<!--NEW Issue Modal start -->
<div class="modal fade" id="Newissue" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel" style='color:black;font-weight:bold;'>New Issue </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
        <form class="form-horizontal" onSubmit="return Newissue_execute();" action="javascript:void(0);">
             
             <div class="form-group">
                <label for="inputEmail3" class="col-sm-3 control-label">Region : </label>
                <div class="col-sm-9">
                  <!--input type="text" class="form-control newinput" id="data_trget" pattern="[A-Z_a-z]{3,15}" title="Enter region NALC/CHINA/EUROPE/JAPAN/MEXCO/SOUTH_KOREA" placeholder="Enter Region" required value=""--->
                  <select class="form-control newinput" id="data_trget">
                    <option value = "China"> China </option>
                    <option value = "Europe"> Europe </option>
                    <option value = "Japan"> Japan </option>
                    <option value = "Mexico"> Mexico </option>
                    <option value = "South_Korea"> South Korea </option>
                    <option value = "NALC"> NALC </option>
                  </select>
                </div>
              </div>
              
              <div class="form-group">
                <label for="inputEmail3" class="col-sm-3 control-label">Issue Name : </label>
                <div class="col-sm-9">
                  <input type="text" class="form-control newinput" id="issue_name" pattern="^[A-Za-z]+[A-Za-z_0-9]{0,19}$" 
                  title =  'Enter a maximum of 20 Characters'
                  oninvalid="this.setCustomValidity(this.willValidate ? '' : 'Issue name should start with alphabets and can even contain _,digits e.g. tote_lock1')"
                  
                  placeholder="Provide issue name without paces " value="">
                </div>
              </div>
              <div class="form-group">
                <label for="inputEmail3" class="col-sm-3 control-label">Issue Description : </label>
                <div class="col-sm-9">
                  <input type="text" class="form-control newinput" id="issue_desc" placeholder="breif the issue  " value="">
                </div>
              </div>
              <div class="form-group">
                <label for="inputEmail3" class="col-sm-3 control-label">category : </label>
                <div class="col-sm-9">
                  <!---input type="text" class="form-control newinput" id="categry" placeholder="Category eg: inbound, outbound" value=""--->
                  <select class="form-control newinput" id="categry">
                    <option value = "Inbound"> Inbound </option>
                    <option value = "Outbound"> Outbound </option>
                    <option value = "Inventory"> Inventory </option>
                    <option value = "Miscellaneous"> Miscellaneous </option>
                  </select>
                </div>
              </div>
              
             <div class="form-group">
                <label for="inputEmail3" class="col-sm-3 control-label">Number of input : </label>
                <div class="col-sm-9">
                  <input type="number" class="form-control newinput" name="no_input"  id="no_input" placeholder=" " value min="1" max="99" value = 1>
                </div>
                
              </div>
              
             <div id="input_n">
              </div>
              
              <script>
                  
                    $('input[type=number]').change(function(){
                      var no_input = document.getElementById('no_input').value ? document.getElementById('no_input').value : 1;
                      console.log(no_input);
                      var i = 0;
                      var inputids = document.getElementById('input_n').getElementsByClassName('newinput')
                      var nbrofips = inputids.length                      
                      console.log("number of inputs: "+ nbrofips)
                      var input_val
                      var input_vals = []
                      if (no_input == nbrofips) 
                          return;

                      for(i=0; i < nbrofips; i++)
                      {
                        console.log(inputids[i].type)
                        input_vals[i] =  inputids[i].value
                      }

                      document.getElementById('input_n').innerHTML = " ";

                      i = 0
                      var input_html = " ";
                      labelval = '&'
                      while(i <  no_input)
                      {
                          
                          input_val = i < nbrofips ? input_vals[i] : ""
                          
                          labelval = i < 9 ? '&0' + (i+1) : '&' + (i+1)
                          i++
                          input_html += "<div class='form-group'> <label for='inputEmail3' class='col-sm-3 control-label'> Input Label"+i+" :</label> <div class='col-sm-9'> <input type='text' class='form-control newinput' name='input_ele'  id='input"+i+"' placeholder=' ' value='"+ input_val + "'> <label class=' control-label'> identifier of input" + i + ": " + labelval + "</label></div> </div> </div>";
                          console.log(input_html);                          
                          
                      }
                      document.getElementById('input_n').innerHTML = input_html;
});
                  
            </script>
          
              <div class="form-group">
              <label for="inputEmail3" class="col-sm-3 control-label">Validation query : </label>
                <div class="col-sm-9">
                  <input type="text" class="form-control newinput" id="vld_query" placeholder="give your update query replace input value with & identifier" value="">
                  <button id = 'addvldqry'>  + </button>
                </div>
                <label for="inputEmail3" class="col-sm-3 control-label">Record Existence : </label>
                <div class="col-sm-9">
                  <input type="text" class="form-control newinput" id="Rcd_Exist" pattern = "^[yYNn]$" title = "Enter Y/N" 
                  oninvalid = "this.setCustomValidity(this.willValidate?'':'should be either Y/N')"
                  required placeholder="Y/N"  style ="width:50px; text-transform:uppercase"  value="">
                  <!--input type="text" class="form-control newinput" id="Rcd_Exist" 
                  required placeholder="Y/N"  style ="width:50px; text-transform:uppercase"  value=""--->
                </div>
                <label for="inputEmail3" class="col-sm-3 control-label">Update query : </label>
                <div class="col-sm-9">
                  <input type="text" class="form-control newinput" id="upt_query" placeholder="give your update query replace input value with & identifier" value="">
                  
                </div>
              </div>

        
          
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Add </button>
        <!--- button type="button" class="btn btn-primary" onclick="Newissue_execute()">Add </button --->
      </div>
    </div>
    </form>
  </div>
</div><!-- New Issue Modal end -->
</div>
  </div>
</div>


    <script src="js/jquery.min.js"></script>
    <script src="js/chart.js"></script>
    <script src="js/tablesorter.min.js"></script>
    <script src="js/toolkit.js"></script>
    <script src="js/application.js"></script>
    <script>
      // execute/clear BS loaders for docs
      $(function(){while(window.BS&&window.BS.loader&&window.BS.loader.length){(window.BS.loader.pop())()}})
    </script>
    <script src="heal.js">
    </script>
  <?php }
  else
  echo "<h1> Sign-in to respective region by navigating to <a href = 'http://localhost/self%20heal%20tool/WMS_LOGIN.PHP'><u> Login </u> </a> page </h1>"
  ?>
  </body>
</html>

