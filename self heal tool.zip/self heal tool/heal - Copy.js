              var r = /^(INC|TASK|inc|task|Inc|Task)\d{7}$/;
        var r_lpn =/(\d{20})(,\s*\d{20})*/g;
        
        function display(dis_name){
            
            if(dis_name === 'inbound'){
                document.getElementById("outbound").style.display="none";
                document.getElementById("inventory").style.display="none";
                document.getElementById("misce").style.display="none";
                document.getElementById("inbound").style.display="block";
            }else if(dis_name === 'outbound'){
                document.getElementById("inbound").style.display="none";
                document.getElementById("misce").style.display="none";
                document.getElementById("inventory").style.display="none";
                document.getElementById("outbound").style.display="block";
            }else if(dis_name === 'inventory'){
                document.getElementById("misce").style.display="none";
                document.getElementById("inbound").style.display="none";
                document.getElementById("outbound").style.display="none";
                document.getElementById("inventory").style.display="block";
            }else if(dis_name === 'misce'){
                document.getElementById("inbound").style.display="none";
                document.getElementById("outbound").style.display="none";
                document.getElementById("inventory").style.display="none";
                document.getElementById("misce").style.display="block";
            }
        }
        
        $.clearInput = function () {
        $('.inputfldcass').find('input[type=text]').val('');
};
       
        function modalclose(){
        $.clearInput();
        }
        
      
    function OLPNexecute(){
        
        var olpnexecute = document.getElementById( "OLPNinput" ).value ? document.getElementById( "OLPNinput" ).value : 'undefined';
        var oincident = document.getElementById( "OIncident" ).value ? document.getElementById( "OIncident" ).value : 'undefined';
        
        console.log(olpnexecute);
        console.log(oincident);
            
       // var r = /^(INC|TASK|inc|task)\d{7}$/;
        //var r_lpn =/(\d{20})(,\s*\d{20})*/;
        if((!olpnexecute || olpnexecute === 'undefined') && (!oincident || oincident === 'undefined')){
           document.getElementById('OLPNinput').style.borderColor="red";
            document.getElementById('OIncident').style.borderColor="red";
           }
        else if (!olpnexecute || olpnexecute === 'undefined'){
            document.getElementById('OLPNinput').style.borderColor="red";
        }
        
        else if(!oincident || oincident === 'undefined'){
            document.getElementById('OIncident').style.borderColor="red";
        }else{
            var check = validate("OIncident","OLPNinput");
            if(check){
                
                var l_check=lpnpattern(olpnexecute);
                if(l_check){
    
    //var q1 ="update lpn set tc_reference_lpn_id = '' ,last_updated_dttm = sysdate,Last_Updated_Source = 'SQL_"+oincident+" where tc_lpn_id in('"+olpnexecute+"') and LPN_FACILITY_STATUS='64' and tc_reference_lpn_id is not null";
                    
      var q1 ="insert into olpn(lpn) values('"+oincident+"')";
             console.log(q1);

            //download(oincident,q1);
            document.getElementById('OLPNinput').value=" ";
            document.getElementById('OIncident').value=" ";
            //document.getElementById('OLPNinput').style.borderColor=none;
            //document.getElementById('OIncident').style.borderColor=none;
                    
                    $.ajax({
                                type: "POST",
                                url: 'mytest.php',
                                dataType: 'json',
                                data: {functionname: 'updateolpn', arguments: [q1, oincident]},

                                success: function (obj, textstatus) {
                                              if( !('error' in obj) ) {
                                                  yourVariable = obj.result;
                                                  console.log(yourVariable);
                                                  console.log("Hi Bala");
                                              }
                                              else {
                                                  console.log(obj.error);
                                                  console.log(yourVariable);
                                                  console.log("Hello Bala");
                                              }
                                        },
                        error: function(err)
                        {
                            console.log(err);
                        }
                            });
                    
            alert("Success : OLPN packed");
                }
            }
        }
        
    }
        
    function Toteexecute(){
        
        var toteexecute = document.getElementById( "Toteinput" ).value ? document.getElementById( "Toteinput" ).value : 'undefined';
        var Iincident = document.getElementById( "Iincident" ).value ? document.getElementById( "Iincident" ).value : 'undefined';
        
        console.log(toteexecute);
        
    if((!toteexecute || toteexecute === 'undefined') && (!Iincident || Iincident === 'undefined')){
           document.getElementById('Toteinput').style.borderColor="red";
            document.getElementById('Iincident').style.borderColor="red";
           }
        else if (!toteexecute || toteexecute === 'undefined'){
            document.getElementById('Toteinput').style.borderColor="red";
        }
        
        else if(!Iincident || Iincident === 'undefined'){
            document.getElementById('Iincident').style.borderColor="red";
        }else{
            var check = validate("Iincident","Toteinput");
            if(check){
                
                var l_check=lpnpattern(toteexecute);
                if(l_check){
    
    var q1 ="update lpn set tc_reference_lpn_id = '' ,last_updated_dttm = sysdate,Last_Updated_Source = 'SQL_"+Iincident+" where tc_lpn_id in('"+toteexecute+"') and LPN_FACILITY_STATUS='64' and tc_reference_lpn_id is not null";
             console.log(q1);

            download(Iincident,q1);
            document.getElementById('Toteinput').value=" ";
            document.getElementById('Iincident').value=" ";
            document.getElementById('Toteinput').style.borderColor=none;
            document.getElementById('Iincident').style.borderColor=none;
            alert("Success : Tote packed");
                }
            }
        }
            
       /* if (!olpnexecute || olpnexecute === 'undefined'){
            document.getElementById('Toteinput').style.borderColor="red";
        }else{
            document.getElementById('Toteinput').style.borderColor="black";
            document.getElementById('Toteinput').value=" ";
            alert("Success : Tote Unlocked");
        }*/
        
    }
        
    function Manifestexecute(){
        
        var olpnexecute = document.getElementById( "Manifestinput" ).value ? document.getElementById( "Manifestinput" ).value : 'undefined';
        
        console.log(olpnexecute);
            
        if (!olpnexecute || olpnexecute === 'undefined'){
            document.getElementById('Manifestinput').style.borderColor="red";
        }else{
            document.getElementById('Manifestinput').style.borderColor="black";
            document.getElementById('Manifestinput').value=" ";
            alert("Success : Manifest move to Invoice");
        }
        
    }
        
         function validate(inc,lpn){
        
        var olpnvalidate = document.getElementById( lpn ).value ? document.getElementById( lpn ).value : 'undefined';
        var incvalidate = document.getElementById( inc ).value ? document.getElementById( inc ).value : 'undefined';
        
        console.log("inside validate"+olpnvalidate+","+incvalidate);
          var r_inc_check = r.test(incvalidate);
            var r_lpn_check = r_lpn.test(olpnvalidate);
            console.log(r_lpn_check+","+r_lpn_check);
            if(!r_inc_check && !r_lpn_check){
                document.getElementById(inc).style.borderColor="red";
                document.getElementById(lpn).style.borderColor="red";
                alert("Enter Valid Incident and LPN");
            }else if(!r_inc_check){
                document.getElementById(inc).style.borderColor="red";
                alert("Enter Valid Incident");
            }else if (!r_lpn_check){
                document.getElementById(lpn).style.borderColor="red";
                alert("Enter Valid LPN"); 
                      }
        else{
            return true;
        }
        
    }
        
    function lpnpattern(lpn){
        //var patt = /(\d{20})(,\s*\d{20})*/igm;
        console.log("hai lpnpattern");
        
        console.log(String(lpn.match(r_lpn)));
        
        if(String(lpn.match(r_lpn))===lpn){
            console.log("lpn and pattern are same");
            return true;
        }else{
            console.log("lpn and pattern are not same");
            alert("Please correct the given LPN");
            return false;
        }
       /* while (match = r_lpn.exec(lpn)) {
            //var v_con = confirm("We counld see the given LPN is not correct. \nDo you want to countinue?\n"+str.slice(patt.lastIndex-1))?;
            console.log(olpn.match(r_lpn).length);
            var v_con = olpn.match(r_lpn).length >1? confirm("We counld see the given LPN is not correct. \nDo you want to countinue?\n"+str.slice(r_lpn.lastIndex)):true;
            if(v_con){
                var l = String(olp.match(r_lpn));
                var p =l.replace(/,,/g,',');
                return true;
                //alert(p);
                
            }else{return false;}

            break;

            }*/
        
                    console.log("lpn last");
            return true;
    }
        
function download(filename, text) {
  var pom = document.createElement('a');
  pom.setAttribute('href', 'data:text/plain;charset=utf-8,' + 

encodeURIComponent(text));
  pom.setAttribute('download', filename);

  pom.style.display = 'none';
  document.body.appendChild(pom);

  pom.click();

  document.body.removeChild(pom);
}
        
function Newissue_execute(){
        
    var tf_flag = true;
    $('.newinput').each(function() { 
        if($(this).val()){
            //console.log('success'+$(this).val());
        }else{
            //console.log('fail'+$(this).val());
            tf_flag = false;
            $(this).css("border", "red solid 1px");
        }
            });   
    
    if(tf_flag){
        console.log('ulle');
        var Data_target = document.getElementById( "data_trget" ).value ? document.getElementById( "data_trget" ).value : 'undefined';
        var Issue_name = document.getElementById( "issue_name" ).value ? document.getElementById( "issue_name" ).value : 'undefined';
        var Category = document.getElementById( "categry" ).value ? document.getElementById( "categry" ).value : 'undefined';
        var no_input = document.getElementById( "no_input" ).value ? document.getElementById( "no_input" ).value : 'undefined';  
        var input_ele = [];
        for (var i = 1; i <= no_input; i++) {
        var input_ele_fld = 'input'+i;
            console.log(input_ele_fld);
            input_ele.push(document.getElementById( input_ele_fld ).value ? document.getElementById( input_ele_fld ).value : 'undefined');
        }
        var Upt_query = document.getElementById( "upt_query" ).value ? document.getElementById( "upt_query" ).value : 'undefined';
        
        console.log(Data_target+' '+Issue_name+' '+Category+' '+no_input+' '+input_ele+' '+Upt_query);
        
                              $.ajax({
                        type: "POST",
                        url: 'mytest.php',
                        dataType: 'json',
                        data: {functionname: 'newissue', arguments: [Data_target, Issue_name, Category, no_input, input_ele, Upt_query]},

                        success: function (obj, textstatus) {
                                      if( !('error' in obj) ) {
                                          yourVariable = obj.result;
                                          console.log(yourVariable);
                                          console.log("Hi Bala");
                                      }
                                      else {
                                          console.log(obj.error);
                                          console.log(yourVariable);
                                          console.log("Hello Bala");
                                      }
                                },
                        error: function(err)
                        {
                            console.log(err);
                        }
                            });
    }
        
} 
        
        function execute(datatgt, modal){
            console.log("hello hello mic check");
            console.log(document.getElementsByClassName("input_fld"+modal));
            var id = document.getElementsByClassName("input_fld"+modal);
            var i =0;
            var parm = [];
            var placehldr = [];
            var flg = true;
            console.log("Lengthuuu "+id.length);
            parm = [];
/*while (i <= (id.length/Math.sqrt(id.length))-1) {
    let p = (id[i].value.split(",")).length === 1 ? "'"+id[i].value.split(",").join("")+"'" : "'"+ id[i].value.split(',').join("','")+"'";
    console.log(p);
    parm.push(p);
    i++;

       
} */
      console.log('testing Gopal started')
      for(var i=0; i < id.length; i++)
      {
        placehldr[i] = id[i].id;
        parm[i]  =  id[i].value;
        console.log("id = " + id[i].id + "value = " + id[i].value);
      }
     
      if(flg){
        
         $.ajax({
                        type: "POST",
                        url: 'selfservic.php',
                        dataType: 'json',
                        data: {functionname: 'executeupdate', arguments: [datatgt, modal, parm]},

                        success: function (dataval) {
                            console.log(dataval);
                            console.log('Bala');
                            console.log(dataval.split("separate"));
                            let c = dataval.split("separate");
                            let i;
                            let text ='';
                            //confirm(dataval);
                            console.log(c.length);
                            for (i = 0; i < c.length; i++) { 
                              text += c[i] + "\n\n";
                                console.log(text);
                            }
                            
                            console.log('Hcheck da');
                                if(confirm(text)){
                                  console.log('Hey!!!successs!!');
                                            $.ajax({
                                                    type: "POST",
                                                    url: 'mytest.php',
                                                    dataType: 'json',
                                                    data: {functionname: 'executequery', arguments: [text]},

                                                    success: function (datav) {
                                                        alert(datav);
                                                        console.log(datav);
/*                                                        $(".alert").delay(4000).slideUp(200, function() {
                                                            $(this).alert('close');
                                                        });*/
                                                        //alert('bala');
                                                        },
                                                    error: function(err)
                                                    {
                                                        console.log("hai da bala eppadi irukka");
                                                        console.log(err.responseText);
                                                    }
                                            });
                                console.log('Hey!!!successs!! after ajax call');
                                
                                
                            }else{
                                  console.log('Ayyo!!!Failed!!');
                            }
                            
                                },
                        error: function(err)
                        {
                            console.log(err);
                        }
                            });

        
    } 
       
            console.log("Modal name : "+modal+" Parametar list : "+parm);

        }

function admin(){
    window.location.href = 'http://localhost/index_admin_login.php';
}