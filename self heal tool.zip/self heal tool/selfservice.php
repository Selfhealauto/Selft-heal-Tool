<?php
$aResult = array();

$aResult['test'] = 'Gopalakrishna';
//$aResult['result'] = "";

if( !isset($_POST['functionname']) ) { $aResult['error'] = 'No function name!'; } //$aResult['result'] = "failed";}

if( !isset($_POST['arguments']) ) { $aResult['error'] = 'No function arguments!'; }

if( !isset($aResult['error']) ) {

    switch($_POST['functionname']) 
    {

        case  'dblogin':
        
            $conn = mysqli_connect('localhost', 'root', '','test');
            $UserType = $_POST['arguments'][3];
             
            if ($UserType == 'Admin')
            {
                $User  = $_POST['arguments'][0];
                $Region = $_POST['arguments'][2];

                $a = "Select  usrpin from usrmst where userid = '$User' and Data_targer = '$Region'";

                $result = mysqli_query($conn,$a);
                if ($row = mysqli_fetch_array($result))
                {
                    if($row['usrpin'] == $_POST['arguments'][1])
                    {
                        $aResult['result'] = 'success';
                    }
                    else
                    {
                        $aResult['error'] = 'Pin Mis-match';
                        
                    }
                }
                else
                {
                    $aResult['error'] = 'User not found';
                }    
                    
            }
            else
            {
                $Region = $_POST['arguments'][2];
                $a = "Select  DBServer from Region where Data_Target = '$Region'";
                $result = mysqli_query($conn, $a);
                if ($row = mysqli_fetch_array($result))
                {
                
                    $aResult['servernm'] = $row['DBServer'];
                // Connects to the XE service (i.e. database) on the "localhost" machine
                    //$ora_conn = oci_connect('READONLY_MANHSUPPORT', 'READONLY_MANHSUPPORT', 'wc1014pe.cz8mdzpqprux.us-east-1.rds.amazonaws.com/WC1014PE');
                    try
                    {
                        $ora_conn = oci_connect($_POST['arguments'][0], $_POST['arguments'][1], $row['DBServer']);                    
                        
                        if (!$ora_conn) 
                            $aResult['error'] = 'Invalid Credentials';
                        else
                        {
                            $aResult['result'] = 'success';
                            $aResult['servernm'] = $row['DBServer'];
                        }
                    }catch(Exeception $e)
                    {
                        $aResult['error'] = 'Invalid Credentials';
                    }
                    
                    
                }
                else
                {
                        $aResult['error'] = 'Region not found';
                }
                // mysqli_close($conn);
            }

            break;
        case 'executeupdate' :
            
            $usrnm = $_POST['arguments'][0];
            $dbpwd = $_POST['arguments'][1];
            $servnm = $_POST['arguments'][2];
            $ora_conn = oci_connect($usrnm, $dbpwd, $servnm);
            //echo "testing connection ";
            
            if (!$ora_conn) {
            
                echo "Connection failed";
                $e = oci_error();
                echo $e['message'];
                //trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
            }
            else
            {
                //echo "<br> connected to oracle server \"" . $servnm . "\" successfully";
          
                $Region = $_POST['arguments'][3];
                $issue = $_POST['arguments'][4];
                $PlcHldrArr = [];
                $ipVals = [];
                $nbrofips = count($_POST['arguments'][5]);
                for($i = 0; $i < $nbrofips; $i++)
                    $PlcHldrArr[$i]=$_POST['arguments'][5][$i];
                
                for($i = 0; $i < $nbrofips; $i++)
                    $ipVals[$i]=$_POST['arguments'][6][$i];

                $a = "Select Query, Rcd_Cnt from query where Data_Target = '$Region' and Issue_Name = '$issue' and qry_type = 'VLD'";
                $conn = mysqli_connect('localhost', 'root', '','test');
                $qryresult = mysqli_query($conn, $a);
    
                $vldflg = 'Y';
    
                while ($row = mysqli_fetch_array($qryresult))
                {
                      $vldqry = $row['Query'];
                      $Rcd_Cnt = $row['Rcd_Cnt'];
                      $i = 0;
                      $nbrofips = count($PlcHldrArr);
                      while($i < $nbrofips)
                      {
                            $vldqry = str_replace($PlcHldrArr[$i], $ipVals[$i], $vldqry);
                            $i++;
                      }
                      //echo "<br> $vldqry";
                      
                      $aResult['vldqry'] = $vldqry;
                      // echo "<br> Record count flag is  $Rcd_Cnt <br>";
                      $stid= oci_parse($ora_conn, $vldqry);
    
                      $r = oci_execute($stid); 
                      
                      if ($wmsrow = oci_fetch_array($stid, OCI_ASSOC+OCI_RETURN_NULLS))
                      {
                          if ($Rcd_Cnt == 'N') 
                          {
                            $aResult['err'] = "problem does not belong $issue issue" ;
                             $vldflg = 'N';
                             break;
                          }
    
                          //else
                       }        //echo "<br> problem belongs to $issue issue";
    
                      else
                      {
                          if ($Rcd_Cnt == 'Y') 
                          {
                             $aResult['err'] = "problem does not belong $issue issue";
                             $vldflg = 'N';
                             break;
                         }
                       }
                    }  // end of while loop that iterates through all validation queries.

                    // start of execution query
                    if ($vldflg == 'Y')
                    {
                        $a = "Select Query, Rcd_Cnt from query where Data_Target = '$Region' and Issue_Name = '$issue' and qry_type = 'EXE'";
                        
                        $result = mysqli_query($conn, $a);

                        while ($row = mysqli_fetch_array($result))
                        {
                                $execqry = $row['Query'];
                                $Rcd_Cnt = $row['Rcd_Cnt'];
                                $i = 0;
                                $nbrofips = count($PlcHldrArr);
                                while($i < $nbrofips)
                                {
                                    $execqry = str_replace($PlcHldrArr[$i], $ipVals[$i], $execqry);
                                    $i++;
                                }
                                $aResult['exeqry'] = $execqry;
                                // echo "<br> Execution Query is:  $execqry";
                                
                        }   
                        mysqli_close($conn);                        

                    }

                    // end of execution query
                     
            } // end of else that checks successfully connected to WMOS data base


            break;
			
             case 'newissue' :
                //date = default_timezone_get();
                $Region = $_POST['arguments'][0];
                $issue = $_POST['arguments'][1];
                $issue_desc = $_POST['arguments'][2];
                $category = $_POST['arguments'][3];
                $nbrofips = $_POST['arguments'][4];
               
                $vld_query = $_POST['arguments'][6];
                $vld_flg = strtoupper($_POST['arguments'][7]);
                $upd_query = $_POST['arguments'][8];
				
				$userid = $_POST['userid'];
				$date=date("y/m/d");
				$timestamp=time();
				$time=date("h:i:s", $timestamp);

                $a = "Select * from menu where Data_Target = '$Region' and Issue_Name = '$issue'";
                $conn = mysqli_connect('localhost', 'root', '','test');
                $qryresult = mysqli_query($conn, $a);

                if ($row = mysqli_fetch_array($qryresult))
                {
                    $aResult['error'] = "Issue with this name already exist";
                    break;
                }
                
                $a = "insert into menu values ('$Region', '$issue', '$issue_desc', '$category', ' ', 0,NULL,'$userid','$date','$time')";
                $retval = mysqli_query( $conn, $a );

                
                $vld_query = str_replace("'", "''", $vld_query);
                
                //echo $vld_query;

                $a = "insert into query values ('$Region', '$issue', 'VLD', 10, '" . $vld_query ."', '$vld_flg','$userid','$date','$time')";
                $retval = mysqli_query( $conn, $a);


                $upd_query = str_replace("'", "''", $upd_query);
                $a = "insert into query values ('$Region', '$issue', 'EXE', 10, '$upd_query', ' ','$userid','$date','$time')";
                $retval = mysqli_query( $conn, $a);
                
                if($retval)
                    $aResult['result'] = 'Issue successfully added';
                

                $nbrofips = count($_POST['arguments'][5]);
                $i = 0;
                while($i < $nbrofips)
                {
                    $iplbl = $_POST['arguments'][5][$i++]; 

                    
                    $PlcHldr = "&" . sprintf("%02d", $i);

                    if ($i < 10) 
                        $PlcHldr = "&0" . $i;
                
                    
                    $seq = $i * 10;
                    $a = "insert into input values ('$Region', '$issue', '$iplbl', '$PlcHldr', $seq,'$userid','$date','$time')";                
                    $retval = mysqli_query( $conn, $a);

                }
                        
                mysqli_close($conn);
                break;

             //end of New Issue   
         // end of switch 

    }    
    
}

echo json_encode($aResult);
?>