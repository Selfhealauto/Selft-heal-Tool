              var r = /^(INC|TASK|inc|task|Inc|Task)\d{7}$/;
        var r_lpn =/(\d{20})(,\s*\d{20})*/g;
        
        function display(dis_name){
            
            if(dis_name === 'inbound'){
                document.getElementById("outbound").style.display="none";
                document.getElementById("inventory").style.display="none";
                document.getElementById("misce").style.display="none";
                document.getElementById("inbound").style.display="block";
            }else if(dis_name === 'outbound'){
                document.getElementById("inbound").style.display="none";
                document.getElementById("misce").style.display="none";
                document.getElementById("inventory").style.display="none";
                document.getElementById("outbound").style.display="block";
            }else if(dis_name === 'inventory'){
                document.getElementById("misce").style.display="none";
                document.getElementById("inbound").style.display="none";
                document.getElementById("outbound").style.display="none";
                document.getElementById("inventory").style.display="block";
            }else if(dis_name === 'misce'){
                document.getElementById("inbound").style.display="none";
                document.getElementById("outbound").style.display="none";
                document.getElementById("inventory").style.display="none";
                document.getElementById("misce").style.display="block";
            }
        }
        
        $.clearInput = function () {
        $('.inputfldcass').find('input[type=text]').val('');
};
       
        function modalclose(){
        $.clearInput();
        }
        
      
    function OLPNexecute(){
        
        var olpnexecute = document.getElementById( "OLPNinput" ).value ? document.getElementById( "OLPNinput" ).value : 'undefined';
        var oincident = document.getElementById( "OIncident" ).value ? document.getElementById( "OIncident" ).value : 'undefined';
        
        console.log(olpnexecute);
        console.log(oincident);
            
       // var r = /^(INC|TASK|inc|task)\d{7}$/;
        //var r_lpn =/(\d{20})(,\s*\d{20})*/;
        if((!olpnexecute || olpnexecute === 'undefined') && (!oincident || oincident === 'undefined')){
           document.getElementById('OLPNinput').style.borderColor="red";
            document.getElementById('OIncident').style.borderColor="red";
           }
        else if (!olpnexecute || olpnexecute === 'undefined'){
            document.getElementById('OLPNinput').style.borderColor="red";
        }
        
        else if(!oincident || oincident === 'undefined'){
            document.getElementById('OIncident').style.borderColor="red";
        }else{
            var check = validate("OIncident","OLPNinput");
            if(check){
                
                var l_check=lpnpattern(olpnexecute);
                if(l_check){
    
    //var q1 ="update lpn set tc_reference_lpn_id = '' ,last_updated_dttm = sysdate,Last_Updated_Source = 'SQL_"+oincident+" where tc_lpn_id in('"+olpnexecute+"') and LPN_FACILITY_STATUS='64' and tc_reference_lpn_id is not null";
                    
      var q1 ="insert into olpn(lpn) values('"+oincident+"')";
             console.log(q1);

            //download(oincident,q1);
            document.getElementById('OLPNinput').value=" ";
            document.getElementById('OIncident').value=" ";
            //document.getElementById('OLPNinput').style.borderColor=none;
            //document.getElementById('OIncident').style.borderColor=none;
                    
                    $.ajax({
                                type: "POST",
                                url: 'mytest.php',
                                dataType: 'json',
                                data: {functionname: 'updateolpn', arguments: [q1, oincident]},

                                success: function (obj, textstatus) {
                                              if( !('error' in obj) ) {
                                                  yourVariable = obj.result;
                                                  console.log(yourVariable);
                                                  console.log("Hi Bala");
                                              }
                                              else {
                                                  console.log(obj.error);
                                                  console.log(yourVariable);
                                                  console.log("Hello Bala");
                                              }
                                        },
                        error: function(err)
                        {
                            console.log(err);
                        }
                            });
                    
            alert("Success : OLPN packed");
                }
            }
        }
        
    }
        
    function Toteexecute(){
        
        var toteexecute = document.getElementById( "Toteinput" ).value ? document.getElementById( "Toteinput" ).value : 'undefined';
        var Iincident = document.getElementById( "Iincident" ).value ? document.getElementById( "Iincident" ).value : 'undefined';
        
        console.log(toteexecute);
        
    if((!toteexecute || toteexecute === 'undefined') && (!Iincident || Iincident === 'undefined')){
           document.getElementById('Toteinput').style.borderColor="red";
            document.getElementById('Iincident').style.borderColor="red";
           }
        else if (!toteexecute || toteexecute === 'undefined'){
            document.getElementById('Toteinput').style.borderColor="red";
        }
        
        else if(!Iincident || Iincident === 'undefined'){
            document.getElementById('Iincident').style.borderColor="red";
        }else{
            var check = validate("Iincident","Toteinput");
            if(check){
                
                var l_check=lpnpattern(toteexecute);
                if(l_check){
    
    var q1 ="update lpn set tc_reference_lpn_id = '' ,last_updated_dttm = sysdate,Last_Updated_Source = 'SQL_"+Iincident+" where tc_lpn_id in('"+toteexecute+"') and LPN_FACILITY_STATUS='64' and tc_reference_lpn_id is not null";
             console.log(q1);

            download(Iincident,q1);
            document.getElementById('Toteinput').value=" ";
            document.getElementById('Iincident').value=" ";
            document.getElementById('Toteinput').style.borderColor=none;
            document.getElementById('Iincident').style.borderColor=none;
            alert("Success : Tote packed");
                }
            }
        }
            
       /* if (!olpnexecute || olpnexecute === 'undefined'){
            document.getElementById('Toteinput').style.borderColor="red";
        }else{
            document.getElementById('Toteinput').style.borderColor="black";
            document.getElementById('Toteinput').value=" ";
            alert("Success : Tote Unlocked");
        }*/
        
    }
        
    function Manifestexecute(){
        
        var olpnexecute = document.getElementById( "Manifestinput" ).value ? document.getElementById( "Manifestinput" ).value : 'undefined';
        
        console.log(olpnexecute);
            
        if (!olpnexecute || olpnexecute === 'undefined'){
            document.getElementById('Manifestinput').style.borderColor="red";
        }else{
            document.getElementById('Manifestinput').style.borderColor="black";
            document.getElementById('Manifestinput').value=" ";
            alert("Success : Manifest move to Invoice");
        }
        
    }
        
         function validate(inc,lpn){
        
        var olpnvalidate = document.getElementById( lpn ).value ? document.getElementById( lpn ).value : 'undefined';
        var incvalidate = document.getElementById( inc ).value ? document.getElementById( inc ).value : 'undefined';
        
        console.log("inside validate"+olpnvalidate+","+incvalidate);
          var r_inc_check = r.test(incvalidate);
            var r_lpn_check = r_lpn.test(olpnvalidate);
            console.log(r_lpn_check+","+r_lpn_check);
            if(!r_inc_check && !r_lpn_check){
                document.getElementById(inc).style.borderColor="red";
                document.getElementById(lpn).style.borderColor="red";
                alert("Enter Valid Incident and LPN");
            }else if(!r_inc_check){
                document.getElementById(inc).style.borderColor="red";
                alert("Enter Valid Incident");
            }else if (!r_lpn_check){
                document.getElementById(lpn).style.borderColor="red";
                alert("Enter Valid LPN"); 
                      }
        else{
            return true;
        }
        
    }
        
    function lpnpattern(lpn){
        //var patt = /(\d{20})(,\s*\d{20})*/igm;
        console.log("hai lpnpattern");
        
        console.log(String(lpn.match(r_lpn)));
        
        if(String(lpn.match(r_lpn))===lpn){
            console.log("lpn and pattern are same");
            return true;
        }else{
            console.log("lpn and pattern are not same");
            alert("Please correct the given LPN");
            return false;
        }
       /* while (match = r_lpn.exec(lpn)) {
            //var v_con = confirm("We counld see the given LPN is not correct. \nDo you want to countinue?\n"+str.slice(patt.lastIndex-1))?;
            console.log(olpn.match(r_lpn).length);
            var v_con = olpn.match(r_lpn).length >1? confirm("We counld see the given LPN is not correct. \nDo you want to countinue?\n"+str.slice(r_lpn.lastIndex)):true;
            if(v_con){
                var l = String(olp.match(r_lpn));
                var p =l.replace(/,,/g,',');
                return true;
                //alert(p);
                
            }else{return false;}

            break;

            }*/
        
                    console.log("lpn last");
            return true;
    }
        
function download(filename, text) {
  var pom = document.createElement('a');
  pom.setAttribute('href', 'data:text/plain;charset=utf-8,' + 

encodeURIComponent(text));
  pom.setAttribute('download', filename);

  pom.style.display = 'none';
  document.body.appendChild(pom);

  pom.click();

  document.body.removeChild(pom);
}
        
function Newissue_execute(){
        
    var tf_flag = true;
    $('.newinput').each(function() { 
        if($(this).val()){
            //console.log('success'+$(this).val());
            $(this).css("border", "grey solid 1px");
        }else{
            console.log('fail'+$(this).val());
            tf_flag = false;
            $(this).css("border", "red solid 1px");
            
        }
            });   
    
        
    
    if(tf_flag){
        console.log('ulle');
        //var Data_target = document.getElementById( "data_trget" ).value ? document.getElementById( "data_trget" ).value : 'undefined';
        var dtaTgtId = document.getElementById( "data_trget" )
        var Data_target = dtaTgtId.options[dtaTgtId.selectedIndex].value
        var Issue_name = document.getElementById( "issue_name" ).value ? document.getElementById( "issue_name" ).value : 'undefined';
        var Issue_desc = document.getElementById( "issue_desc" ).value ? document.getElementById( "issue_desc").value : 'undefined';
        var ctgId = document.getElementById( "categry" )
        //var Category = document.getElementById( "categry" ).value ? document.getElementById( "categry" ).value : 'undefined';
        var Category = ctgId.options[ctgId.selectedIndex].value
        var no_input = document.getElementById( "no_input" ).value ? document.getElementById( "no_input" ).value : 'undefined';  
        var input_ele = [];
        if (no_input == 0)
           input_ele.push("none")
        
        for (var i = 1; i <= no_input; i++) {
        
            var input_ele_fld = 'input'+i;
            console.log(input_ele_fld);
            input_ele.push(document.getElementById( input_ele_fld ).value ? document.getElementById( input_ele_fld ).value : 'undefined');
        }
        var Vld_query = document.getElementById( "vld_query" ).value ? document.getElementById( "vld_query" ).value : 'undefined';
        var Vld_flg = document.getElementById( "Rcd_Exist" ).value ? document.getElementById( "Rcd_Exist" ).value : 'undefined';
        
        var Upt_query = document.getElementById( "upt_query" ).value ? document.getElementById( "upt_query" ).value : 'undefined';
        
        console.log(Data_target+' '+Issue_name+' '+Category+' '+no_input+' '+input_ele+' '+Upt_query);
        
                              $.ajax({
                        type: "POST",
                        url: 'selfservice.php',
                        dataType: 'json',
                        data: {functionname: 'newissue', arguments: [Data_target, Issue_name, Issue_desc, Category, no_input, input_ele, Vld_query, Vld_flg, Upt_query]},

                        success: function (obj, textstatus) {
                                      if( !('error' in obj) ) {
                                        alert(obj.result)
                                          yourVariable = obj.result;
                                          console.log(yourVariable);
                                          console.log(obj.vldqry1)
                                          console.log(obj.vldqry2)
                                          console.log("Hi Gopal");
                                          var ipclass = document.getElementsByClassName('newinput')
                                          for(var i=0 ; i < ipclass.length; i++)
                                          { 
                                              ipclass[i].value = "" 

                                          }   
                                          document.getElementById('input_n').innerHTML = " ";
                                      }

                                      else {
                                          console.log(obj.error);
                                          alert(obj.error)
                                          // console.log(yourVariable);
                                          console.log("Hello Krishna");
                                      }
                                },
                        error: function(err)
                        {
                            console.log(err);
                        }
                            });
    }
    return(false)
        
} 
        
        function execute(datatgt, modal, userid, password, server){
            //console.log("hello hello mic check");
            // console.log(document.getElementsByClassName("input_fld"+modal));
            var mdlid = "#"+datatgt.trim() + modal.trim()
            var id = document.getElementsByClassName("input_fld"+modal);
            var btnId = document.getElementById('execbtn'+ modal)
            var i =0;
            var parm = [];
            var placehldr = [];
            //console.log("Lengthuuu "+id.length);
            var parm = [];
            var flg = true;
/*while (i <= (id.length/Math.sqrt(id.length))-1) {
    let p = (id[i].value.split(",")).length === 1 ? "'"+id[i].value.split(",").join("")+"'" : "'"+ id[i].value.split(',').join("','")+"'";
    console.log(p);
    parm.push(p);
    i++;

       
} */
      console.log('testing Gopal started' + datatgt+ " issue: " + modal)
      for(var i=0; i < id.length; i++)
      {
        placehldr[i] = id[i].name;
        parm[i]  =  id[i].value;
        console.log("id = " + id[i].name + "value = " + id[i].value);
        if (parm[i].trim()  == "")
            flg = false;
      }
      /*userid = 'READONLY_MANHSUPPORT'
      password = 'READONLY_MANHSUPPORT'
      server = 'wc1014pe.cz8mdzpqprux.us-east-1.rds.amazonaws.com/WC1014PE' */
      console.log("flag value is " + flg)
      if(flg){
        btnId.innerHTML = '<span class="spinner-grow spinner-grow-sm" role="status" aria-hidden="false"></span>  Executing in...';
        btnId.disabled = true;
    
         $.ajax({
                        type: "POST",
                        url: 'selfservice.php',
                        dataType: 'json',
                        data: {functionname: 'executeupdate', arguments: [userid, password, server, datatgt, modal, placehldr, parm]},

                        success: function (dataval) {
                          
                            console.log("Executed the post request to self service" + dataval.vldqry)
                            if  ("err" in dataval)
                            {
                                console.log(dataval.err)
                                window.alert(dataval.err)
                            }
                            if ("exeqry" in  dataval)
                            {
                                console.log("Executed the post request to self service" + dataval.exeqry)
                                window.alert("Issue resolved successfully")
                                modalclose()
                            }
                            btnId.innerHTML = 'Execute';
                            btnId.disabled = false;

                            
                           // $(mdlid).modal('hide')

                                },

                        error: function(err)
                        {
                            btnId.innerHTML = 'Execute';
                            btnId.disabled = false;
                            window.alert("Something went wrong !!! Try again")
                            console.log(err);
                        }
                            });        
    } 
    
            
            
            console.log("Modal name : "+modal+" Parametar list : "+parm);

        }

function admin(){
    window.location.href = 'http://localhost/index_admin_login.php';
}